PowerShame
====================================

The Powershame backend, powered by Flask


Requirements:
    - virtualenv/pip
    - gunicorn (/nginx)

On Ubuntu:
sudo apt-get install python-pip virtualenvwrapper mysql-client libmysqlclient-dev
