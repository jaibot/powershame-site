# Create, manage, and delete sessions
# Decide whether to grant new session requests
# TODO
