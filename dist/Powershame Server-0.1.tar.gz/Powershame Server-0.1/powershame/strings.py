class Strings:
    app_name =         "Powershame"
    your_sessions =    "Sessions"
    your_shamers =     "Friends"
    about =            "How Does This Work?"
