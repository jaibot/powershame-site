class Urls:
    sessions =     "/sessions"
    shamers =      "/shamers"
    profile =      "/profile"
    login =        "/login"
    logout =       "/logout"
    signup =       "/signup"
